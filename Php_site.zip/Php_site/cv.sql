-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 19 mai 2020 à 19:36
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cv`
--

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

CREATE TABLE `contact` (
  `id_position` int(3) NOT NULL,
  `munero` varchar(20) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `twiter` varchar(100) DEFAULT NULL,
  `insta` varchar(100) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`id_position`, `munero`, `facebook`, `Email`, `twiter`, `insta`, `image`) VALUES
(2, '06.15.03.10.41', 'aaa', 'AlexandreA1.kramer@gmail.com', 'fff', 'fff', 'images/profile2.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `diplomes`
--

CREATE TABLE `diplomes` (
  `id_position` int(3) NOT NULL,
  `date_obtention` varchar(30) DEFAULT NULL,
  `lieux` varchar(50) DEFAULT NULL,
  `nom_diplome` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `diplomes`
--

INSERT INTO `diplomes` (`id_position`, `date_obtention`, `lieux`, `nom_diplome`) VALUES
(1, 'test', 'test', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `experiance`
--

CREATE TABLE `experiance` (
  `id_position` int(3) NOT NULL,
  `date_stage` varchar(30) DEFAULT NULL,
  `entreprise` varchar(50) DEFAULT NULL,
  `info` varchar(500) DEFAULT NULL,
  `nom_stage` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `experiance`
--

INSERT INTO `experiance` (`id_position`, `date_stage`, `entreprise`, `info`, `nom_stage`) VALUES
(2, 'test', 'test3', 'test2', 'test'),
(3, 'test', 'test3', 'test2', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `identiter`
--

CREATE TABLE `identiter` (
  `id_position` int(3) NOT NULL,
  `domain` varchar(50) DEFAULT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `phrase1` varchar(50) DEFAULT NULL,
  `phrase2` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `identiter`
--

INSERT INTO `identiter` (`id_position`, `domain`, `nom`, `phrase1`, `phrase2`) VALUES
(1, 'Developpent Informatique ', 'Alexandre Kramer', 'Bonjour je suis', 'Etudiant en ');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_position` int(3) NOT NULL,
  `nom_utilisateur` varchar(30) DEFAULT NULL,
  `mot_de_passe` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_position`, `nom_utilisateur`, `mot_de_passe`) VALUES
(0, 'admin', 'admin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id_position`);

--
-- Index pour la table `diplomes`
--
ALTER TABLE `diplomes`
  ADD PRIMARY KEY (`id_position`);

--
-- Index pour la table `experiance`
--
ALTER TABLE `experiance`
  ADD PRIMARY KEY (`id_position`);

--
-- Index pour la table `identiter`
--
ALTER TABLE `identiter`
  ADD PRIMARY KEY (`id_position`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id_position`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `diplomes`
--
ALTER TABLE `diplomes`
  MODIFY `id_position` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `experiance`
--
ALTER TABLE `experiance`
  MODIFY `id_position` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `identiter`
--
ALTER TABLE `identiter`
  MODIFY `id_position` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
